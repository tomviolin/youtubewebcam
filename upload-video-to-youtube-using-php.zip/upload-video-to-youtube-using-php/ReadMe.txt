Author: CodexWorld
Author URL: http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/upload-video-to-youtube-using-php/

============ Introduction ============
This project helps web developers to upload videos to YouTube from web application using PHP.

============ Installation ============
1. Create a database (codexworld) at phpMyAdmin.
2. Import the videos.sql file into the database (codexworld).
3. Open the "includes/DB.php" file and modify the $dbHost, $dbUsername, $dbPassword and $dbName variables value with your MySQL details into the __construct() function.
4. Open the "config.php" file and modify the $oauthClientID, $oauthClientSecret, $baseUri and $redirectUri variables values.
5. Run the index.php file at the browser and test the functionalities.

============ May I Help You ===========
If you have any query about this script, please feel free to comment here - http://www.codexworld.com/upload-video-to-youtube-using-php/#respond. We will reply your query ASAP.